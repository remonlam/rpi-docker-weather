from __future__ import absolute_import
from .sense_hat import SenseHat, SenseHat as AstroPi

__version__ = '2.1.0'
